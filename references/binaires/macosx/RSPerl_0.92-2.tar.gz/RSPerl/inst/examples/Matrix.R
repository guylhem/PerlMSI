Matrix <-
function(data, r, c)
{
  cat("In Matrix")
   print(data)
  matrix(data, r, c)
}
