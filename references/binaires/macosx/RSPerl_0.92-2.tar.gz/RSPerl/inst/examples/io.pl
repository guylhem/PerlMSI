
sub myOpen {
    my $f = shift;
    open(HH, $f);
    return(HH);
}


