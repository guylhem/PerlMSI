print "In source.pl\n";

$xx = 1;
@xy = (1,2,3);

sub Test {
    printf "In Test\n";
    return 1;
}
