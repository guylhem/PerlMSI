use subs qw(exit);
exit( ) if $DEBUG;
sub exit { warn "exit( ) was called"; }

