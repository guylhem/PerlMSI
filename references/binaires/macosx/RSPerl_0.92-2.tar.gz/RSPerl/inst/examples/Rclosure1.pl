#!/usr/bin/perl
use strict;
use R;
use RReferences;

   

#
# FIXME:
#   This program reproduces the bug related to calling R closure
#   We suspect that this is related to stack management.
#   Placing a break point in R.c:121
#


R::initR("--silent");

R::eval("mkfunc<<-function() {    function()  1  } ");

my $z = R::mkfunc();

for (1..3)
{
    my @foo;  # providing an initialization value removes the problem, i.e. () - not {}
    print "Bug: ", scalar($#foo), "\n"; # if ($_ != 2);    # bug, there should be no keys in %foo
    push (@foo, 1);
    my $zz = R::call($z);
}
