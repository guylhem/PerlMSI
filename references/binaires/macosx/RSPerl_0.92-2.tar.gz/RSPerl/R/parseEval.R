parseEval <-
function(cmd)
{
 eval(parse(text = cmd))
}
