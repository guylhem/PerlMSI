.PerlLength <-
function(obj)
{
  .Call(RS_PerlLength, obj)
}

