.PerlClear <-
function(ref)
{
  .Call(RS_PerlClear, ref)
}
