getPerl5LibValue = 
function()
{
  "/tmp/RR/RSPerl/perl"
}

getPerlDynModules = 
function()
{
  c("R")
}
