#ifndef RPERL_ELEMENTS_H
#define RPERL_ELEMENTS_H

#include "RSPerl.h"

USER_OBJECT_ RS_PerlArrayElement(USER_OBJECT_ rs_arr, USER_OBJECT_ elements, USER_OBJECT_ convert);
USER_OBJECT_ RS_PerlHashElement(USER_OBJECT_ rs_table, USER_OBJECT_ elements, USER_OBJECT_ convert);

#endif
