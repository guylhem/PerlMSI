#ifndef TRY_EVAL_H
#define TRY_EVAL_H

#include "RSCommon.h"

USER_OBJECT_ tryEval(USER_OBJECT_ e, int *ErrorOccurred);

#endif
